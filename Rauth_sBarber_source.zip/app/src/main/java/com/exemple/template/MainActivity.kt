/*
 * File: app/src/main/java/com/exemple/template/MainActivity.kt
 * Version: 8.0.11 (Fullscreen 3-Button Orientation Fix)
 */
package com.exemple.template

import android.Manifest
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkInfo
import android.net.Uri
import android.app.DownloadManager
import android.os.Environment
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebBackForwardList
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ArrayAdapter
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListPopupWindow
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlin.math.max
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout

class MainActivity : AppCompatActivity() {
    private lateinit var swipeRefreshLayout: SwipeRefreshLayout

    private lateinit var webView: WebView
    private var popupDialog: Dialog? = null
    private var popupWebView: WebView? = null

    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null
    private var pendingPermissionRequest: PermissionRequest? = null
    private var lastFailingUrl: String? = null
    private var networkCallback: ConnectivityManager.NetworkCallback? = null
    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null
    private var originalOrientation: Int = 0

    companion object {
        private const val FILE_CHOOSER_REQUEST_CODE = 1001
        private const val WEBVIEW_PERMISSION_REQUEST_CODE = 1002
    }



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        WindowCompat.setDecorFitsSystemWindows(window, false)

        val topAppBar: Toolbar = findViewById(R.id.topAppBar)
        setSupportActionBar(topAppBar)

        val rootView = findViewById<View>(R.id.main)
        val fakeStatusBar = findViewById<View>(R.id.fakeStatusBar)
        val contentContainer = findViewById<View>(R.id.swipeRefreshLayout)
        

        val rootBasePaddingLeft = rootView.paddingLeft
        val rootBasePaddingTop = rootView.paddingTop
        val rootBasePaddingRight = rootView.paddingRight
        val rootBasePaddingBottom = rootView.paddingBottom

        val appBarBasePaddingLeft = topAppBar.paddingLeft
        val appBarBasePaddingTop = topAppBar.paddingTop
        val appBarBasePaddingRight = topAppBar.paddingRight
        val appBarBasePaddingBottom = topAppBar.paddingBottom

        val contentBasePaddingLeft = contentContainer.paddingLeft
        val contentBasePaddingTop = contentContainer.paddingTop
        val contentBasePaddingRight = contentContainer.paddingRight
        val contentBasePaddingBottom = contentContainer.paddingBottom
        val contentLayoutParams = contentContainer.layoutParams as ViewGroup.MarginLayoutParams
        val contentBaseMarginLeft = contentLayoutParams.leftMargin
        val contentBaseMarginTop = contentLayoutParams.topMargin
        val contentBaseMarginRight = contentLayoutParams.rightMargin
        val contentBaseMarginBottom = contentLayoutParams.bottomMargin
        

        val primaryColorInt = Color.parseColor("#000000")
        val isPrimaryLightForSystemBars = isColorLight(primaryColorInt)
        val initialIsLandscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val initialClassicNavColorInt = if (initialIsLandscape) {
            Color.argb(204, Color.red(primaryColorInt), Color.green(primaryColorInt), Color.blue(primaryColorInt))
        } else {
            primaryColorInt
        }
        rootView.setBackgroundColor(primaryColorInt)
        window.setBackgroundDrawable(ColorDrawable(primaryColorInt))
        window.statusBarColor = primaryColorInt
        window.navigationBarColor = initialClassicNavColorInt
        WindowInsetsControllerCompat(window, window.decorView).isAppearanceLightNavigationBars = isPrimaryLightForSystemBars
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            window.isNavigationBarContrastEnforced = false
        }

        

        ViewCompat.setOnApplyWindowInsetsListener(rootView) { _, insets ->
            val statusBarInsets = insets.getInsets(WindowInsetsCompat.Type.statusBars())
            val navigationBarInsets = insets.getInsets(WindowInsetsCompat.Type.navigationBars())
            val tappableInsets = insets.getInsets(WindowInsetsCompat.Type.tappableElement())
            val systemGestureInsets = insets.getInsets(WindowInsetsCompat.Type.systemGestures())
            val imeInsets = insets.getInsets(WindowInsetsCompat.Type.ime())
            val gestureNavMaxPx = (40 * resources.displayMetrics.density).toInt()
            val likelyGestureNav = tappableInsets.bottom == 0 &&
                systemGestureInsets.bottom > 0 &&
                navigationBarInsets.bottom <= gestureNavMaxPx
            val hasClassicNavBar = !likelyGestureNav
            val navController = WindowInsetsControllerCompat(window, window.decorView)
            val isLandscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
            // In landscape, keep content behind 3-button nav so translucent bar overlays the content.
            val navBottomInsetForLayout = if (hasClassicNavBar && !isLandscape) navigationBarInsets.bottom else 0
            val bottomInset = max(navBottomInsetForLayout, imeInsets.bottom)
            val leftInset = max(statusBarInsets.left, navigationBarInsets.left)
            val rightInset = max(statusBarInsets.right, navigationBarInsets.right)
            val classicNavColorInt = if (isLandscape) {
                Color.argb(204, Color.red(primaryColorInt), Color.green(primaryColorInt), Color.blue(primaryColorInt))
            } else {
                primaryColorInt
            }

            if (hasClassicNavBar) {
                window.navigationBarColor = classicNavColorInt
                navController.isAppearanceLightNavigationBars = isPrimaryLightForSystemBars
            } else {
                window.navigationBarColor = Color.TRANSPARENT
                navController.isAppearanceLightNavigationBars = true
            }
            navController.isAppearanceLightStatusBars = isPrimaryLightForSystemBars

            rootView.setPadding(
                rootBasePaddingLeft,
                rootBasePaddingTop,
                rootBasePaddingRight,
                rootBasePaddingBottom
            )

            contentLayoutParams.setMargins(
                contentBaseMarginLeft + navigationBarInsets.left,
                contentBaseMarginTop,
                contentBaseMarginRight + navigationBarInsets.right,
                contentBaseMarginBottom + bottomInset
            )
            contentContainer.layoutParams = contentLayoutParams
            

            topAppBar.setPadding(
                appBarBasePaddingLeft + leftInset,
                appBarBasePaddingTop,
                appBarBasePaddingRight + rightInset,
                appBarBasePaddingBottom
            )

            contentContainer.setPadding(
                contentBasePaddingLeft,
                contentBasePaddingTop,
                contentBasePaddingRight,
                contentBasePaddingBottom
            )

            fakeStatusBar.visibility = View.VISIBLE
            fakeStatusBar.layoutParams.height = statusBarInsets.top
            fakeStatusBar.requestLayout()

            insets
        }
        ViewCompat.requestApplyInsets(rootView)

        webView = findViewById(R.id.webView)


        // === SMART SPLASH v4.0 (LockOverlay Architecture) ===
        val startTime = System.currentTimeMillis()
        val splashOverlay = findViewById<View>(R.id.splashOverlay)
        var splashHidden = false

        fun hideSplash() {
            if (splashHidden) return
            splashHidden = true

            // System bars are fully managed by insets logic (dynamic color + contrast)

            // Show WebView BEFORE fading out splash to prevent black flash
            webView.visibility = View.VISIBLE
            splashOverlay.animate()
                .alpha(0f)
                .setDuration(300)
                .withEndAction {
                    splashOverlay.visibility = View.GONE
                }
                .start()
        }

        // Normal splash behavior (no lock screen)
        webView.visibility = View.INVISIBLE
        Handler(Looper.getMainLooper()).postDelayed({ hideSplash() }, 2500)

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                url ?: return false
                return when {
                    // 🆕 LOCAL CONTENT: Handle local:// links
                    url.startsWith("local://") -> {
                        val localPath = url.removePrefix("local://")
                        view?.loadUrl("file:///android_asset/www/$localPath")
                        true
                    }
                    url.startsWith("mailto:") -> {
                        try { startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse(url))) } catch (e: Exception) {}
                        true
                    }
                    url.startsWith("tel:") -> {
                        try { startActivity(Intent(Intent.ACTION_DIAL, Uri.parse(url))) } catch (e: Exception) {}
                        true
                    }
                    url.startsWith("sms:") || url.startsWith("smsto:") -> {
                        try { startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse(url))) } catch (e: Exception) {}
                        true
                    }
                    url.startsWith("whatsapp:") || url.startsWith("https://wa.me/") -> {
                        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (e: Exception) {}
                        true
                    }
                    url.startsWith("geo:") -> {
                        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (e: Exception) {}
                        true
                    }
                    url.startsWith("http://") || url.startsWith("https://") -> {
                        // Check internet before loading external URL
                        if (isInternetAvailable()) {
                            view?.loadUrl(url)
                            false
                        } else {
                            // No internet, show custom error page without adding to history
                            lastFailingUrl = url
                            view?.loadDataWithBaseURL(null, getOfflineHtml(), "text/html", "UTF-8", null)
                            true  // We handled it
                        }
                    }
                    // 🆕 LOCAL FILES: Check if file exists before loading
                    url.startsWith("file://") -> {
                        val filePath = url.removePrefix("file:///android_asset/")
                        try {
                            val assetManager = assets
                            assetManager.open(filePath).close()
                            false  // File exists, let WebView handle it
                        } catch (e: Exception) {
                            // File doesn't exist, show custom error page
                            view?.loadDataWithBaseURL(null, getFileNotFoundHtml(), "text/html", "UTF-8", null)
                            true  // We handled it
                        }
                    }
                    url.contains("://") -> {
                        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (e: Exception) {}
                        true
                    }
                    else -> false
                }
            }
            
            override fun onReceivedError(view: WebView?, errorCode: Int, description: String?, failingUrl: String?) {
                super.onReceivedError(view, errorCode, description, failingUrl)

                // Network errors - fallback if internet drops mid-load
                if (errorCode == WebViewClient.ERROR_HOST_LOOKUP ||
                    errorCode == WebViewClient.ERROR_CONNECT ||
                    errorCode == WebViewClient.ERROR_TIMEOUT ||
                    errorCode == WebViewClient.ERROR_IO) {

                    if (failingUrl != null && !failingUrl.startsWith("data:") && !failingUrl.startsWith("about:")) {
                        lastFailingUrl = failingUrl
                    }

                    if (!isOnErrorPage()) {
                        view?.stopLoading()
                        view?.loadDataWithBaseURL(null, getOfflineHtml(), "text/html", "UTF-8", null)
                    }
                }

                if (::swipeRefreshLayout.isInitialized) { swipeRefreshLayout.isRefreshing = false }
            }
            
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                if (::swipeRefreshLayout.isInitialized) { swipeRefreshLayout.isRefreshing = false }
                
                val elapsedTime = System.currentTimeMillis() - startTime
                val remainingTime = if (elapsedTime < 1000) 1000 - elapsedTime else 0
                Handler(Looper.getMainLooper()).postDelayed({ hideSplash() }, remainingTime)
            }
        }
        
        swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout)
        swipeRefreshLayout.setOnRefreshListener {
            if (isOnErrorPage()) {
                if (isInternetAvailable()) {
                    performRecovery()
                    Handler(Looper.getMainLooper()).postDelayed({ 
                        if (::swipeRefreshLayout.isInitialized) swipeRefreshLayout.isRefreshing = false 
                    }, 1000)
                } else {
                    swipeRefreshLayout.isRefreshing = false
                    Toast.makeText(this, "No Internet Connection", Toast.LENGTH_SHORT).show()
                }
            } else {
                webView.reload()
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            
            override fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message?): Boolean {

                // Block automatic popups (ads, scripts) - only allow user-initiated popups
                if (!isUserGesture) {
                    return false
                }

                val result = view?.hitTestResult
                val type = result?.type
                
                if (type == WebView.HitTestResult.SRC_ANCHOR_TYPE || type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE) {
                    val transport = resultMsg?.obj as? WebView.WebViewTransport
                    if (transport != null) {
                        val tempWebView = WebView(this@MainActivity)
                        tempWebView.webViewClient = object : WebViewClient() {
                            override fun onLoadResource(view: WebView?, url: String?) {
                                if (url != null) {
                                    webView.loadUrl(url)
                                    tempWebView.destroy()
                                }
                            }
                        }
                        transport.webView = tempWebView
                        resultMsg.sendToTarget()
                    }
                    return true
                }
                
                val popupWebView = WebView(this@MainActivity)
                popupWebView.settings.javaScriptEnabled = true
                popupWebView.settings.domStorageEnabled = true
                popupWebView.settings.javaScriptCanOpenWindowsAutomatically = true
                popupWebView.settings.userAgentString = webView.settings.userAgentString
                
                val popupCookieManager = CookieManager.getInstance()
                popupCookieManager.setAcceptCookie(true)
                popupCookieManager.setAcceptThirdPartyCookies(popupWebView, true)
                
                // 🌙 DARK MODE SUPPORT FOR POPUP
                val isDarkMode = isSystemInDarkMode() // Use the new function

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
                        WebSettingsCompat.setAlgorithmicDarkeningAllowed(popupWebView.settings, isDarkMode)
                    }
                } else {
                    if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) {
                        WebSettingsCompat.setForceDark(
                            popupWebView.settings,
                            if (isDarkMode) WebSettingsCompat.FORCE_DARK_ON else WebSettingsCompat.FORCE_DARK_OFF
                        )
                    }
                }
                
                popupWebView.webViewClient = object : WebViewClient() {
                     override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                        url ?: return false
                        return when {
                            url.startsWith("mailto:") -> {
                                try { startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse(url))) } catch (e: Exception) {}
                                true
                            }
                            url.startsWith("tel:") -> {
                                try { startActivity(Intent(Intent.ACTION_DIAL, Uri.parse(url))) } catch (e: Exception) {}
                                true
                            }
                            url.startsWith("http://") || url.startsWith("https://") -> {
                                view?.loadUrl(url)
                                false
                            }
                            else -> {
                                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (e: Exception) {}
                                true
                            }
                        }
                    }
                }
                
                popupWebView.webChromeClient = object : WebChromeClient() {
                    override fun onCloseWindow(window: WebView?) {
                        popupDialog?.dismiss()
                        popupDialog = null
                        this@MainActivity.popupWebView = null
                    }
                }
                
                val transport = resultMsg?.obj as? WebView.WebViewTransport
                transport?.webView = popupWebView
                resultMsg?.sendToTarget()
                
                showPopupDialog(popupWebView)
                
                return true
            }

            override fun onGeolocationPermissionsShowPrompt(origin: String?, callback: GeolocationPermissions.Callback?) {
                callback?.invoke(origin, true, false)
            }

            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    val missingPermissions = request.resources.map {
                        if (it == PermissionRequest.RESOURCE_VIDEO_CAPTURE) Manifest.permission.CAMERA
                        else Manifest.permission.RECORD_AUDIO 
                    }.filter { ContextCompat.checkSelfPermission(this@MainActivity, it) != PackageManager.PERMISSION_GRANTED }
                    
                    if (missingPermissions.isEmpty()) request.grant(request.resources)
                    else {
                        pendingPermissionRequest = request
                        ActivityCompat.requestPermissions(this@MainActivity, missingPermissions.toTypedArray(), WEBVIEW_PERMISSION_REQUEST_CODE)
                    }
                }
            }
            
            override fun onShowFileChooser(webView: WebView?, filePathCallback: ValueCallback<Array<Uri>>?, fileChooserParams: FileChooserParams?): Boolean {
                fileChooserCallback?.onReceiveValue(null)
                this@MainActivity.fileChooserCallback = filePathCallback
                try {
                    val intent = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply { type = "*/*"; addCategory(Intent.CATEGORY_OPENABLE) }
                    startActivityForResult(Intent.createChooser(intent, "Choose File"), FILE_CHOOSER_REQUEST_CODE)
                    return true
                } catch (e: Exception) {
                    this@MainActivity.fileChooserCallback = null
                    return false
                }
            }

            override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                if (customView != null) {
                    callback?.onCustomViewHidden()
                    return
                }
                customView = view
                customViewCallback = callback
                originalOrientation = requestedOrientation
                
                val decorView = window.decorView as FrameLayout
                decorView.addView(customView, FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                ))
                
                window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
                requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR
            }

            override fun onHideCustomView() {
                if (customView == null) return
                
                window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
                val decorView = window.decorView as FrameLayout
                decorView.removeView(customView)
                customView = null
                customViewCallback?.onCustomViewHidden()
                customViewCallback = null
                requestedOrientation = originalOrientation
            }
        }

        // 🌙 DARK MODE SUPPORT
        val isDarkMode = isSystemInDarkMode() // Use the new function

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            // Android 13+ (API 33+) utilise Algorithmic Darkening
            if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
                WebSettingsCompat.setAlgorithmicDarkeningAllowed(webView.settings, isDarkMode)
            }
        } else {
            // Android 10-12 (API 29-32) utilise Force Dark
            if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) {
                WebSettingsCompat.setForceDark(
                    webView.settings,
                    if (isDarkMode) WebSettingsCompat.FORCE_DARK_ON else WebSettingsCompat.FORCE_DARK_OFF
                )
            }
        }

        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.userAgentString = settings.userAgentString?.replace("wv", "")?.replace("; ", " ")
        settings.domStorageEnabled = true 
        settings.databaseEnabled = true
        settings.setGeolocationEnabled(true)
        settings.mediaPlaybackRequiresUserGesture = false
        settings.setSupportMultipleWindows(true)
        settings.javaScriptCanOpenWindowsAutomatically = true

        settings.builtInZoomControls = false
        settings.displayZoomControls = false

        // 📁 LOCAL MODE: Allow file access for local content
        settings.allowFileAccess = true
        settings.allowContentAccess = true

        // 📥 DOWNLOAD LISTENER: Handle file downloads from WebView
        webView.setDownloadListener { url, userAgent, contentDisposition, mimeType, contentLength ->
            try {
                if (url.startsWith("data:")) {
                    val commaIndex = url.indexOf(',')
                    if (commaIndex > 0) {
                        val encodedData = url.substring(commaIndex + 1)
                        val decodedData = java.net.URLDecoder.decode(encodedData, "UTF-8")
                        var fileName = "download"
                        val ext = when {
                            mimeType.contains("json") -> ".json"
                            mimeType.contains("text") -> ".txt"
                            mimeType.contains("csv") -> ".csv"
                            else -> ""
                        }
                        if (!fileName.contains(".")) fileName += ext
                        val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                        val file = java.io.File(downloadsDir, fileName)
                        file.writeText(decodedData)
                        android.media.MediaScannerConnection.scanFile(this, arrayOf(file.absolutePath), null, null)
                        Toast.makeText(this, "Fichier sauvegardé", Toast.LENGTH_SHORT).show()
                    }
                } else if (!url.startsWith("blob:")) {
                    val fileName = android.webkit.URLUtil.guessFileName(url, contentDisposition, mimeType)
                    val request = DownloadManager.Request(Uri.parse(url))
                    request.setMimeType(mimeType)
                    request.addRequestHeader("User-Agent", userAgent)
                    request.setTitle(fileName)
                    request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
                    val dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                    dm.enqueue(request)
                    Toast.makeText(this, "Téléchargement démarré", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this, "Erreur téléchargement", Toast.LENGTH_SHORT).show()
            }
        }

        // REGLAGES CACHE (NETTOYAGE NUCLÉAIRE SI NOCACHE)
        
        settings.cacheMode = WebSettings.LOAD_DEFAULT
        val cookieManager = CookieManager.getInstance()
        cookieManager.setAcceptCookie(true)
        cookieManager.setAcceptThirdPartyCookies(webView, true)
        

        // 🆕 LOAD URL: Local content or remote URL
        webView.loadUrl(getString(R.string.website_url))

        supportActionBar?.setDisplayShowTitleEnabled(false)
        val titleLayout = LinearLayout(this)
        titleLayout.orientation = LinearLayout.HORIZONTAL
        titleLayout.gravity = Gravity.CENTER_VERTICAL
        
        val primaryColor = Color.parseColor("#000000")
        val isPrimaryLight = isColorLight(primaryColor)
        val toolbarTextColor = if (isPrimaryLight) Color.BLACK else Color.WHITE
        
        try {
            val appIcon = ContextCompat.getDrawable(this, R.mipmap.ic_launcher)
            val bitmap = appIcon?.toBitmap(32.dpToPx(), 32.dpToPx())
            val iconDrawable = BitmapDrawable(resources, bitmap)
            val appIconView = ImageView(this)
            appIconView.setImageDrawable(iconDrawable)
            appIconView.setPadding(2.dpToPx(), 0, 6.dpToPx(), 0)
            titleLayout.addView(appIconView)
        } catch (e: Exception) { e.printStackTrace() }
        
        val titleView = TextView(this)
        titleView.text = getString(R.string.app_name)
        titleView.setTextColor(toolbarTextColor)
        titleView.textSize = 20f
        titleView.setTypeface(null, Typeface.BOLD)
        titleLayout.addView(titleView)
        topAppBar.addView(titleLayout)
        val titleParams = titleLayout.layoutParams as Toolbar.LayoutParams
        titleParams.gravity = Gravity.START or Gravity.CENTER_VERTICAL
        titleParams.marginStart = 4.dpToPx()
        titleLayout.layoutParams = titleParams



        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {

                // If on error page, go back twice to skip the failed URL
                if (isOnErrorPage()) {
                    val list = webView.copyBackForwardList()
                    // Find a valid page to go back to (skip failed URLs)
                    var stepsBack = 1
                    for (i in list.currentIndex - 1 downTo 0) {
                        val item = list.getItemAtIndex(i)
                        val url = item?.url ?: ""
                        if (url != lastFailingUrl && !url.startsWith("data:") && url != "about:blank") {
                            break
                        }
                        stepsBack++
                    }
                    if (list.currentIndex >= stepsBack) {
                        webView.goBackOrForward(-stepsBack)
                    } else {
                        finish()
                    }
                } else if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    finish()
                }
            }
        })

        // 🔥🔥🔥 NETWORK CALLBACK REGISTRATION 🔥🔥🔥
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        
        networkCallback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                // Network is available, wait 2 seconds for DNS to stabilize
                runOnUiThread {
                    Handler(Looper.getMainLooper()).postDelayed({
                        // Only trigger if we are actively showing the error page
                        if (isOnErrorPage()) {
                            performRecovery()
                        }
                    }, 2000)
                }
            }
        }

        // Register callback (API 24+ vs older)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            connectivityManager.registerDefaultNetworkCallback(networkCallback!!)
        } else {
            val builder = android.net.NetworkRequest.Builder()
            connectivityManager.registerNetworkCallback(builder.build(), networkCallback!!)
        }

    }

    
    private fun isOnErrorPage(): Boolean {
        val url = webView.url
        return url != null && (url.startsWith("data:") || url == "about:blank")
    }

    private fun performRecovery() {
        if (isOnErrorPage()) {
             // 1. Force isShowingOfflineError reset implicitly by actions below

             if (webView.canGoBack()) {
                // "Swipe Left" simulation
                webView.goBack()
             } else {
                // App started offline, load the target URL directly
                val targetUrl = lastFailingUrl ?: getString(R.string.website_url)
                webView.loadUrl(targetUrl)
             }
        }
    }

    private fun isInternetAvailable(): Boolean {
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val network = connectivityManager.activeNetwork ?: return false
            val capabilities = connectivityManager.getNetworkCapabilities(network) ?: return false
            capabilities.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            capabilities.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        } else {
            @Suppress("DEPRECATION")
            val networkInfo = connectivityManager.activeNetworkInfo
            networkInfo != null && networkInfo.isConnected
        }
    }

    // NETTOYAGE FINAL (onDestroy)
    
    override fun onDestroy() {
        super.onDestroy()
        networkCallback?.let {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            cm.unregisterNetworkCallback(it)
        }
    }
        

    // 🪟 RESTORED V1.3.0 POPUP LAYOUT LOGIC
    private fun getOfflineHtml(): String {
        val locale = resources.configuration.locales[0]
        val lang = locale.language
        
        val title = when (lang) {
            "fr" -> "Réseau indisponible"
            "es" -> "Red no disponible"
            "it" -> "Rete non disponibile"
            "pt" -> "Rede indisponível"
            "de" -> "Netzwerk nicht verfügbar"
            else -> "Network Unavailable"
        }
        
        val message = when (lang) {
            "fr" -> "Aucune connexion internet n'est disponible."
            "es" -> "No hay conexión a internet disponible."
            "it" -> "Nessuna connessione Internet disponibile."
            "pt" -> "Nenhuma conexão com a Internet disponível."
            "de" -> "Keine Internetverbindung verfügbar."
            else -> "No internet connection available."
        }
        
        val primaryColor = "#000000"
        val textColor = "#FFFFFF"
        
        fun hexToRgb(hex: String): Triple<Int, Int, Int> {
            val h = hex.removePrefix("#")
            val r = h.substring(0, 2).toInt(16)
            val g = h.substring(2, 4).toInt(16)
            val b = h.substring(4, 6).toInt(16)
            return Triple(r, g, b)
        }
        
        fun getLuminance(r: Int, g: Int, b: Int): Double {
            return (0.299 * r + 0.587 * g + 0.114 * b) / 255.0
        }
        
        val (r, g, b) = hexToRgb(primaryColor)
        val luminance = getLuminance(r, g, b)
        
        fun createGradientColors(r: Int, g: Int, b: Int, lum: Double): Pair<String, String> {
            return when {
                lum > 0.95 -> {
                    val lightGray = "rgb(245, 245, 247)"
                    val mediumGray = "rgb(229, 229, 234)"
                    Pair(lightGray, mediumGray)
                }
                lum > 0.85 -> {
                    val light = "rgb(${Math.max(0, r - 15)}, ${Math.max(0, g - 15)}, ${Math.max(0, b - 15)})"
                    val dark = "rgb(${Math.max(0, r - 40)}, ${Math.max(0, g - 40)}, ${Math.max(0, b - 40)})"
                    Pair(light, dark)
                }
                lum > 0.7 -> {
                    val light = "rgb(${Math.max(0, r - 20)}, ${Math.max(0, g - 20)}, ${Math.max(0, b - 20)})"
                    val dark = "rgb(${Math.max(0, r - 50)}, ${Math.max(0, g - 50)}, ${Math.max(0, b - 50)})"
                    Pair(light, dark)
                }
                lum < 0.05 -> {
                    val darkGray = "rgb(18, 18, 20)"
                    val lighterGray = "rgb(38, 38, 42)"
                    Pair(darkGray, lighterGray)
                }
                lum < 0.15 -> {
                    val dark = "rgb(${Math.min(255, r + 10)}, ${Math.min(255, g + 10)}, ${Math.min(255, b + 10)})"
                    val lighter = "rgb(${Math.min(255, r + 30)}, ${Math.min(255, g + 30)}, ${Math.min(255, b + 30)})"
                    Pair(dark, lighter)
                }
                lum < 0.3 -> {
                    val dark = "rgb(${Math.min(255, r + 15)}, ${Math.min(255, g + 15)}, ${Math.min(255, b + 15)})"
                    val lighter = "rgb(${Math.min(255, r + 40)}, ${Math.min(255, g + 40)}, ${Math.min(255, b + 40)})"
                    Pair(dark, lighter)
                }
                else -> {
                    val variation = 25
                    val light = "rgb(${Math.min(255, r + variation)}, ${Math.min(255, g + variation)}, ${Math.min(255, b + variation)})"
                    val dark = "rgb(${Math.max(0, r - variation)}, ${Math.max(0, g - variation)}, ${Math.max(0, b - variation)})"
                    Pair(light, dark)
                }
            }
        }
        
        val (gradientLight, gradientDark) = createGradientColors(r, g, b, luminance)
        
        return """
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <style>
                    * { margin: 0; padding: 0; box-sizing: border-box; }
                    html, body {
                        height: 100%;
                        width: 100%;
                    }
                    body {
                        display: flex;
                        flex-direction: column;
                        background: linear-gradient(135deg, $gradientLight 0%, $gradientDark 100%);
                        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                    }
                    .content {
                        flex: 1;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        padding: 20px;
                    }
                    .container {
                        text-align: center;
                        color: $textColor;
                        max-width: 400px;
                    }
                    .icon {
                        font-size: 80px;
                        margin-bottom: 20px;
                        display: block;
                        animation: float 3s ease-in-out infinite;
                    }
                    @keyframes float {
                        0%, 100% { transform: translateY(0); }
                        50% { transform: translateY(-10px); }
                    }
                    h1 {
                        margin: 0 0 10px 0;
                        font-size: 28px;
                        font-weight: 600;
                        letter-spacing: -0.5px;
                    }
                    p {
                        margin: 0;
                        opacity: 0.9;
                        font-size: 16px;
                        line-height: 1.5;
                    }
                </style>
            </head>
            <body>
                <div class="content">
                    <div class="container">
                        <div class="icon">📡</div>
                        <h1>$title</h1>
                        <p>$message</p>
                    </div>
                </div>
            </body>
            </html>
        """.trimIndent()
    }

    private fun getFileNotFoundHtml(): String {
        val locale = resources.configuration.locales[0]
        val lang = locale.language

        val title = when (lang) {
            "fr" -> "Page introuvable"
            "es" -> "Página no encontrada"
            "it" -> "Pagina non trovata"
            "pt" -> "Página não encontrada"
            "de" -> "Seite nicht gefunden"
            else -> "Page Not Found"
        }

        val message = when (lang) {
            "fr" -> "Le lien demandé n'existe pas ou a été déplacé."
            "es" -> "El enlace solicitado no existe o ha sido movido."
            "it" -> "Il link richiesto non esiste o è stato spostato."
            "pt" -> "O link solicitado não existe ou foi movido."
            "de" -> "Der angeforderte Link existiert nicht oder wurde verschoben."
            else -> "The requested link doesn't exist or has been moved."
        }

        val primaryColor = "#000000"
        val textColor = "#FFFFFF"

        fun hexToRgb(hex: String): Triple<Int, Int, Int> {
            val h = hex.removePrefix("#")
            val r = h.substring(0, 2).toInt(16)
            val g = h.substring(2, 4).toInt(16)
            val b = h.substring(4, 6).toInt(16)
            return Triple(r, g, b)
        }

        fun getLuminance(r: Int, g: Int, b: Int): Double {
            return (0.299 * r + 0.587 * g + 0.114 * b) / 255.0
        }

        val (r, g, b) = hexToRgb(primaryColor)
        val luminance = getLuminance(r, g, b)

        fun createGradientColors(r: Int, g: Int, b: Int, lum: Double): Pair<String, String> {
            return when {
                lum > 0.95 -> Pair("rgb(245, 245, 247)", "rgb(229, 229, 234)")
                lum > 0.85 -> Pair("rgb(${Math.max(0, r - 15)}, ${Math.max(0, g - 15)}, ${Math.max(0, b - 15)})", "rgb(${Math.max(0, r - 40)}, ${Math.max(0, g - 40)}, ${Math.max(0, b - 40)})")
                lum > 0.7 -> Pair("rgb(${Math.max(0, r - 20)}, ${Math.max(0, g - 20)}, ${Math.max(0, b - 20)})", "rgb(${Math.max(0, r - 50)}, ${Math.max(0, g - 50)}, ${Math.max(0, b - 50)})")
                lum < 0.05 -> Pair("rgb(18, 18, 20)", "rgb(38, 38, 42)")
                lum < 0.15 -> Pair("rgb(${Math.min(255, r + 10)}, ${Math.min(255, g + 10)}, ${Math.min(255, b + 10)})", "rgb(${Math.min(255, r + 30)}, ${Math.min(255, g + 30)}, ${Math.min(255, b + 30)})")
                lum < 0.3 -> Pair("rgb(${Math.min(255, r + 15)}, ${Math.min(255, g + 15)}, ${Math.min(255, b + 15)})", "rgb(${Math.min(255, r + 40)}, ${Math.min(255, g + 40)}, ${Math.min(255, b + 40)})")
                else -> {
                    val variation = 25
                    Pair("rgb(${Math.min(255, r + variation)}, ${Math.min(255, g + variation)}, ${Math.min(255, b + variation)})", "rgb(${Math.max(0, r - variation)}, ${Math.max(0, g - variation)}, ${Math.max(0, b - variation)})")
                }
            }
        }

        val (gradientLight, gradientDark) = createGradientColors(r, g, b, luminance)

        return """
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <style>
                    * { margin: 0; padding: 0; box-sizing: border-box; }
                    html, body { height: 100%; width: 100%; }
                    body {
                        display: flex;
                        flex-direction: column;
                        background: linear-gradient(135deg, $gradientLight 0%, $gradientDark 100%);
                        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                    }
                    .content {
                        flex: 1;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        padding: 20px;
                    }
                    .container {
                        text-align: center;
                        color: $textColor;
                        max-width: 400px;
                    }
                    .icon {
                        font-size: 80px;
                        margin-bottom: 20px;
                        display: block;
                        animation: shake 2s ease-in-out infinite;
                    }
                    @keyframes shake {
                        0%, 100% { transform: rotate(0deg); }
                        25% { transform: rotate(-5deg); }
                        75% { transform: rotate(5deg); }
                    }
                    h1 {
                        margin: 0 0 10px 0;
                        font-size: 28px;
                        font-weight: 600;
                        letter-spacing: -0.5px;
                    }
                    p {
                        margin: 0;
                        opacity: 0.9;
                        font-size: 16px;
                        line-height: 1.5;
                    }
                </style>
            </head>
            <body>
                <div class="content">
                    <div class="container">
                        <div class="icon">🔗</div>
                        <h1>$title</h1>
                        <p>$message</p>
                    </div>
                </div>
            </body>
            </html>
        """.trimIndent()
    }

    private fun showPopupDialog(popupWebView: WebView) {
        val dialog = Dialog(this, android.R.style.Theme)
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)
        
        val primaryColorString = "#000000"
        val primaryColorInt = Color.parseColor(primaryColorString)
        val isPopupPrimaryLight = isColorLight(primaryColorInt)
        val closeButtonTextColor = if (isPopupPrimaryLight) Color.BLACK else Color.WHITE

        val container = LinearLayout(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, 0)
        }
        
        val fakeStatusBar = View(this).apply {
            setBackgroundColor(primaryColorInt)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0 
            )
        }
        container.addView(fakeStatusBar)
        
        val webViewParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            0,
            1f 
        )
        container.addView(popupWebView, webViewParams)
        
        val buttonOverlay = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT
            )
        }
        
        val closeButton = TextView(this).apply {
            text = "✕"
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(closeButtonTextColor)
            setBackgroundColor(primaryColorInt)
            elevation = 12f
            isClickable = true
            isFocusable = true
            
            setOnClickListener {
                popupWebView.destroy()
                dialog.dismiss()
                popupDialog = null
                this@MainActivity.popupWebView = null
            }
        }
        
        val closeButtonSize = (24 * resources.displayMetrics.density).toInt()
        val tinyMargin = (4 * resources.displayMetrics.density).toInt()
        val closeButtonParams = FrameLayout.LayoutParams(closeButtonSize, closeButtonSize).apply {
            gravity = Gravity.TOP or Gravity.END
            setMargins(0, tinyMargin, tinyMargin, 0)
        }
        buttonOverlay.addView(closeButton, closeButtonParams)
        
        val outerContainer = FrameLayout(this).apply {
            addView(container, FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            ))
            addView(buttonOverlay, FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            ))
        }
        
        ViewCompat.setOnApplyWindowInsetsListener(outerContainer) { v, insets ->
            val statusBarHeight = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top
            fakeStatusBar.layoutParams.height = statusBarHeight
            fakeStatusBar.requestLayout()
            closeButtonParams.setMargins(0, statusBarHeight + tinyMargin, tinyMargin, 0)
            closeButton.requestLayout()
            v.setPadding(0, 0, 0, 0)
            WindowInsetsCompat.CONSUMED
        }
        
        dialog.window?.apply {
            decorView.setPadding(0, 0, 0, 0)
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            setBackgroundDrawableResource(android.R.color.transparent)
            
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
                addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN)
                clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
                clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION)
                
                val red = Color.red(primaryColorInt)
                val green = Color.green(primaryColorInt)
                val blue = Color.blue(primaryColorInt)
                val semiTransparent = Color.argb(204, red, green, blue)
                
                statusBarColor = semiTransparent
                navigationBarColor = semiTransparent
            }
            
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val decorView = this.decorView
                var flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                           View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                           View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                
                flags = if (isPopupPrimaryLight) {
                    flags or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
                } else {
                    flags
                }
                decorView.systemUiVisibility = flags
            }
        }
        
        dialog.setContentView(outerContainer)
        
        dialog.setOnKeyListener { _, keyCode, event ->
            if (keyCode == android.view.KeyEvent.KEYCODE_BACK && event.action == android.view.KeyEvent.ACTION_UP) {
                popupWebView.destroy()
                dialog.dismiss()
                popupDialog = null
                this@MainActivity.popupWebView = null
                true
            } else {
                false
            }
        }
        
        dialog.show()
        popupDialog = dialog
        this.popupWebView = popupWebView
    }

    @Deprecated("Deprecated in API 33")
    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)

    }
    private fun isSystemInDarkMode(): Boolean {
        return (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }
    
    private fun Int.dpToPx(): Int = (this * resources.displayMetrics.density).toInt()

    private fun isColorLight(color: Int): Boolean {
        val red = android.graphics.Color.red(color)
        val green = android.graphics.Color.green(color)
        val blue = android.graphics.Color.blue(color)
        val luminance = (0.299 * red + 0.587 * green + 0.114 * blue) / 255
        return luminance > 0.5
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == WEBVIEW_PERMISSION_REQUEST_CODE && pendingPermissionRequest != null) {
            val allGranted = grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }
            if (allGranted) pendingPermissionRequest?.grant(pendingPermissionRequest!!.resources)
            else pendingPermissionRequest?.deny()
            pendingPermissionRequest = null
        }
    }
    
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == FILE_CHOOSER_REQUEST_CODE) {
            fileChooserCallback?.onReceiveValue(if (resultCode == RESULT_OK) {
                if (data?.clipData != null) Array(data.clipData!!.itemCount) { i -> data.clipData!!.getItemAt(i).uri }
                else if (data?.data != null) arrayOf(data.data!!)
                else null
            } else null)
            fileChooserCallback = null
        }
    }

}