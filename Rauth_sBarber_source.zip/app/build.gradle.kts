plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
}

android {
    namespace = "com.exemple.template"
    compileSdk = 36

    signingConfigs {
        create("release") {
            // Read properties for signing. This is a secure way to handle credentials.
            // They can be set in local.properties or passed via command line.
            val storeFile = project.findProperty("upload.store.file")
            val storePassword = project.findProperty("upload.store.password")
            val keyAlias = project.findProperty("upload.key.alias")
            val keyPassword = project.findProperty("upload.key.password")

            if (storeFile != null) {
                this.storeFile = file(storeFile as String)
                this.storePassword = storePassword as String?
                this.keyAlias = keyAlias as String?
                this.keyPassword = keyPassword as String?
            }
        }
    }

    defaultConfig {
        applicationId = "com.rauth_sbarber.app"
        minSdk = 26  // Android 8.0 - Dexing plus rapide
        targetSdk = 36
        versionCode = 120
        versionName = "01.002"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = signingConfigs.getByName("release")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    // 🚀 Désactiver Lint pour builds serveur (économise ~6 secondes)
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.material)
    implementation(libs.androidx.activity)
    implementation(libs.androidx.constraintlayout)

    // Dépendance WebKit pour le contrôle avancé de la WebView
    implementation("androidx.webkit:webkit:1.9.0")

    // Optional dependencies (pre-cached for clients)
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")

    // Tests désactivés pour builds serveur (économise du temps)
    // testImplementation(libs.junit)
    // androidTestImplementation(libs.androidx.junit)
    // androidTestImplementation(libs.androidx.espresso.core)
}
